# BacBo Analyzer

Projeto para análise de sequência de BacBo com recomendação em tempo real.

## Deploy no Vercel
1. Faça login em [Vercel](https://vercel.com)
2. Clique em "New Project"
3. Escolha "Import from GitHub" e selecione este repositório
4. Deploy automático pronto para uso no navegador (iOS-friendly)